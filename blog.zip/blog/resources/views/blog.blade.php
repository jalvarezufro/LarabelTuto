@extends('plantilla')

@section('seccion')
    <h1>blog<h1>
@endsection

