@extends('plantilla')

@section('seccion')
    <h1>foto<h1>
        @endsection
