@extends('plantilla')

@section('seccion')
    <h2>Nombre: {{$nota->nombre}}<br>Descripcion: {{$nota->descripcion}}</h2>

@endsection