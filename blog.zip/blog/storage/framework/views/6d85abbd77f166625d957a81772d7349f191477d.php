

<?php $__env->startSection('seccion'); ?>
    <h2>Nombre: <?php echo e($nota->nombre); ?><br>Descripcion: <?php echo e($nota->descripcion); ?></h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\blog\resources\views/notas/detalle.blade.php ENDPATH**/ ?>