

<?php $__env->startSection('seccion'); ?>
    <h1>blog<h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\blog\resources\views/blog.blade.php ENDPATH**/ ?>