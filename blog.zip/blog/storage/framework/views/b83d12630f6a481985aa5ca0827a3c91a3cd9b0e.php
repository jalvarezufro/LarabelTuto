

<?php $__env->startSection('seccion'); ?>
    <h1>Este es el equipo de trabajo</h1>

    <?php $__currentLoopData = $equipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('our', $item)); ?>" class="h4 text-danger"><?php echo e($item); ?></a><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(!empty($nombre)): ?>
        <?php switch($nombre):

            case ($nombre=="Ignacio"): ?>
            <h2 class="mt-5">El nombre es <?php echo e($nombre); ?>:</h2>
            <p><?php echo e($nombre); ?> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Molestiae modi quo expedita
                incidunt itaque officia nulla, provident dignissimos, ipsum blanditiis sapiente, iure nostrum saepe eveniet
                voluptate! Itaque maiores odio voluptatem?</p>
            <?php break; ?>

            <?php case ($nombre=="Pedrito"): ?>
            <h2 class="mt-5">El nombre es <?php echo e($nombre); ?>:</h2>
            <p><?php echo e($nombre); ?> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Molestiae modi quo expedita
                incidunt itaque officia nulla, provident dignissimos, ipsum blanditiis sapiente, iure nostrum saepe eveniet
                voluptate! Itaque maiores odio voluptatem?</p>
            <?php break; ?>

            <?php case ($nombre=="Juanito"): ?>
            <h2 class="mt-5">El nombre es <?php echo e($nombre); ?>:</h2>
            <p><?php echo e($nombre); ?> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Molestiae modi quo expedita
                incidunt itaque officia nulla, provident dignissimos, ipsum blanditiis sapiente, iure nostrum saepe eveniet
                voluptate! Itaque maiores odio voluptatem?</p>
            <?php break; ?>

    
<?php $__env->stopSection(); ?>
        <?php endswitch; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\blog\resources\views/nosotros.blade.php ENDPATH**/ ?>