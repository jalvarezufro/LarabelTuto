<?php $__env->startSection('seccion'); ?>
    </head>

    <body>
        <div class="container my-4">
            <h1 class="display-4">Notas </h1>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">id</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Descripcion</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <th scope="row"><?php echo e($nota->id); ?></th>
                        <td><a href="<?php echo e(route('notas.detalle', $nota)); ?>"><?php echo e($nota->nombre); ?></a>
                        </td>
                        <td><?php echo e($nota->descripcion); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\blog\resources\views/welcome.blade.php ENDPATH**/ ?>